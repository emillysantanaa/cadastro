﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace funcionario
{
   
    public partial class Empresa : Form
    {
        public List<Cadastro_empresa> listempresa;

        public Empresa()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bt_Cadastrar_Click(object sender, EventArgs e)
        {
            try
            {
               
                Cadastro_empresa empresa = new Cadastro_empresa();
                empresa.RazaoSocial = tx_RazaoSocial.Text;
                empresa.NomeFantasia = tx_nomeFantasia.Text;
                empresa.SituacaoCadastral = Convert.ToString(cb_situacaoCadastral);
                empresa.RegimeTributario = Convert.ToString(panelRegime);
                empresa.DataInicio = Convert.ToDateTime(msk_data);
                empresa.Telefonee = msk_telefone.Text;
                empresa.CapitalSocial = Convert.ToDouble(tx_capitalSocial);
                empresa.Endereco = tx_enderecoo.Text;
                empresa.Cidade = tx_cidadee.Text;
                empresa.Estado = cb_estado.Text;
                empresa.Tipo = Tipo();
                empresa.PorteEmpresa = Porte();
                empresa.Cidade = tx_cidadee.Text;
                empresa.NomeProprietario = tx_noomeProprie.Text ;
                empresa.CpfProprietarrio = msk_cpfProprie.Text ;

                Inserir(empresa);

                MessageBox.Show($"Empresa cadastrada com sucesso!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
        void Inserir(Cadastro_empresa empresas)
        {
            try
            {


                Conexao conexao = new Conexao();

                var comando = conexao.Comando("INSERT INTO Empresa(cnpj_emp, razao_social_emp, nome_fant_emp," +
                    " situacao_cadastral_emp, regime_Tributario_emp, data_inicio_emp, telefone_emp, capital_social_emp," +
                    "tipo_emp, porte_empresa_emp, natureza_juridica_emp, nome_prop_emp, cpf_prop_emp) VALUES (" +
                    " @Cnpj, @RazaoSocial, @NomeFantasia, @Situacao, @RegimeTrib, @DataInicio, @Telefone, @CapitalSocial, " +
                    "@Estado, @Cidade, @Tipo, @PorteEmpresa, @NaturezaJuridica, @NomeProprietariio, @CpfDoProprietarioo)");

                comando.Parameters.AddWithValue("@Cnpj", empresas.cnpj);
                comando.Parameters.AddWithValue("@RazaoSocial", empresas.RazaoSocial);
                comando.Parameters.AddWithValue("@NomeFantasia", empresas.NomeFantasia);
                comando.Parameters.AddWithValue("@Situacao", empresas.SituacaoCadastral);
                comando.Parameters.AddWithValue("@Regime", empresas.RegimeTributario);
                comando.Parameters.AddWithValue("@DataInicio", empresas.DataInicio);
                comando.Parameters.AddWithValue("@Telefone", empresas.Telefonee);
                comando.Parameters.AddWithValue("@CapitalSocial", empresas.CapitalSocial);
                comando.Parameters.AddWithValue("@Estado", empresas.Estado);
                comando.Parameters.AddWithValue("@Cidade", empresas.Cidade);
                comando.Parameters.AddWithValue("@Tipo", empresas.Tipo);
                comando.Parameters.AddWithValue("@PorteEmpresa", empresas.PorteEmpresa);
                comando.Parameters.AddWithValue("@NaturezaJuridica", empresas.NaturezaJuridica);
                comando.Parameters.AddWithValue("@NomeProprietariio", empresas.NomeProprietario);
                comando.Parameters.AddWithValue("@CpfDoProprietarioo", empresas.CpfProprietarrio);

                var resultado = comando.ExecuteNonQuery();

                if (resultado > 0)
                {
                    MessageBox.Show("Empresa cadastrado com sucesso!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public string Regime()
        {
            string radio = "";

            foreach (Control ctrl in panelRegime.Controls)
            {
                if (ctrl is RadioButton rb && rb.Checked)
                {
                    radio = rb.Text;
                    break;
                }
            }

            return radio;
        }
        public string Tipo()
        {
            string radio = "";

            foreach (Control ctrl in panelTipo.Controls)
            {
                if (ctrl is RadioButton rb && rb.Checked)
                {
                    radio = rb.Text;
                    break;
                }
            }

            return radio;
        }
        public string Porte()
        {
            string radio = "";

            foreach (Control ctrl in panelPorte.Controls)
            {
                if (ctrl is RadioButton rb && rb.Checked)
                {
                    radio = rb.Text;
                    break;
                }
            }

            return radio;
        }
        private void bt_Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    }

