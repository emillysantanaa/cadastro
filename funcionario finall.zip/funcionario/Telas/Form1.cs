﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace funcionario
{
    public partial class Form1 : Form
    {
        List<Cadastro> funcionario;
        MySqlConnection Conexao;

        public Form1()
        {

            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cb_funcao_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string validarcpf = mkd_cpf.Text;
                bool Resulcpf = CPF.ValidacaoCpf(validarcpf);

                if (Resulcpf)
                {
                    Cadastro funcionario = new Cadastro();
                    funcionario.Nome = tx_nome.Text;
                    funcionario.EstadoCivil = cb_estadocivil.Text;
                    funcionario.DataNascimento = mkd_datanascimento.Text;
                    funcionario.RG = tx_rg.Text;
                    funcionario.CPF = mkd_cpf.Text;
                    funcionario.Email = tx_email.Text;
                    funcionario.Telefone = mkd_telefone.Text;
                    funcionario.Endereco = tx_endereco.Text;
                    funcionario.Cidade = tx_cidade.Text;
                    funcionario.Estado = tx_estado.Text;
                    funcionario.Funcao = tx_funcao.Text;
                    funcionario.Salario = Convert.ToDouble(tx_salario.Text);

                    Inserir(funcionario);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        void Inserir(Cadastro f)
        {

            try
            {
                Conexao conexao = new Conexao();

                var comando = conexao.Comando("INSERT INTO Funcionario (nome_fun, cpf_fun, rg_fun, estadoCivil_fun, data_nascimento_fun, " +
                    "celular_fun, estado_fun, cidade_fun,endereco_fun, email_fun, funcao_fun, salario_fun)" +
                    "VALUES (@Nome, @CPF, @RG, @EstadoCivil, @DataNascimento, @Telefone, @Estado, @Cidade, @Endereco, @Email, @Funcao, @Salario)");

                comando.Parameters.AddWithValue("@Nome", f.Nome);
                comando.Parameters.AddWithValue("@CPF", f.CPF);
                comando.Parameters.AddWithValue("@RG", f.RG);
                comando.Parameters.AddWithValue("@EstadoCivil", f.EstadoCivil);
                comando.Parameters.AddWithValue("@DataNascimento", f.DataNascimento);
                comando.Parameters.AddWithValue("@Telefone", f.Telefone);
                comando.Parameters.AddWithValue("@Estado", f.Estado);
                comando.Parameters.AddWithValue("@Cidade", f.Cidade);
                comando.Parameters.AddWithValue("@Endereco", f.Endereco);
                comando.Parameters.AddWithValue("@Email", f.Email);
                comando.Parameters.AddWithValue("@Funcao", f.Funcao);
                comando.Parameters.AddWithValue("@Salario", f.Salario);

                var resultado = comando.ExecuteNonQuery();

                if (resultado > 0)
                {
                    MessageBox.Show("Funcionário cadastrado com sucesso");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}

